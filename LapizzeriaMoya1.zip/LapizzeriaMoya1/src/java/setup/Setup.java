package setup;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Basket;
import model.Pizza;
import model.User;

/**
 * Servlet implementation class Setup
 */
public class Setup extends HttpServlet {

    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Setup() {
        super();
// TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


// adding content to servlet context
        ServletContext c = getServletContext();

        ArrayList<Pizza> pizzas = (ArrayList<Pizza>) c.getAttribute("pizzas");
        if (pizzas == null) {

// creating content


            Pizza p1 = new Pizza("Margherita", 43, "Tomato, Cheese, Blue cheese", 0);
            Pizza p2 = new Pizza("Hawaii", 65, "Tomato, Cheese, Ham, Pineapple", 1);
            Pizza p3 = new Pizza("Vesuvioe", 57, "Tomato, Cheese, Kinder-egg", 2);
            Pizza p4 = new Pizza("Capricciosa", 70, "Cheese, Ham, Pinapple", 3);
            Pizza p5 = new Pizza("Napoli", 47, "Tomato, Cheese, Beef", 4);
            Pizza p6 = new Pizza("Hawaii vegie", 47, "Tomato, Cheese, Pinapple", 5);
            Pizza p7 = new Pizza("Italiana", 65, "Tomato, Cheese, Bearnaise", 6);
            Pizza p8 = new Pizza("Sahara", 82, "Onion, Ham, Pinapple", 7);
            Pizza p9 = new Pizza("Margerita", 45, "Tomato, Cheese", 8);
            Pizza p10 = new Pizza("Sahara", 65, "Potato, Cheese, champignon , Pinapple", 9);
            Pizza p11 = new Pizza("Americana", 57, "Tomato, Cheese, Mushroom", 10);
            Pizza p12 = new Pizza("Samos", 630, "Cheese, Ham, Pinapple", 11);
            Pizza p13 = new Pizza("Greacy", 45, "Tomato, Cheese", 12);
            Pizza p14 = new Pizza("Verona", 75, "Tomato, Cheese, Ham, Pinapple", 13);
            Pizza p15 = new Pizza("Anne Special", 52, "Tomato, Cheese, Beef, Mushroom", 14);
            Pizza p16 = new Pizza("Viking", 83, "Cheese, Gorgonzola, Tomato", 15);
            Pizza p17 = new Pizza("Pepper Peter", 82, "Tomato, Cheese, Chorizo, Chili", 16);
            Pizza p18 = new Pizza("Spinat", 45, "Tomato, Cheese, Gorgonzola", 17);
            Pizza p19 = new Pizza("Hawaii", 67, "Tomato, Cheese, Chorizo, Pinapple", 18);
            Pizza p20 = new Pizza("Bacone", 55, "Tomato, Cheese, Bacone", 19);
            Pizza p21 = new Pizza("Milano", 76, "Cheese, Pepperoni , Beef", 20);
            Pizza p22 = new Pizza("Sicilia", 47, "Tomato, Cheese, Champignon, Aananas", 21);
            Pizza p23 = new Pizza("Matador", 59, "Tomato, Cheese, Champignon,Paprika ", 22);
            Pizza p24 = new Pizza("Quatro Stagioni", 54, "Tomato, Cheese, champignon , Mushroom", 23);
            Pizza p25 = new Pizza("Musi", 62, "Bacon, Champignon, Squash, Pinapple", 24);
            Pizza p26 = new Pizza("Lazio", 55, "Tomato, Cheese, Fish", 25);
            Pizza p27 = new Pizza("Mama Rosa", 67, "Potato, Cheese, Champignon, Beef", 56);
            Pizza p28 = new Pizza("Opera", 59, "Tomato, Cheese, Fish, Champignon", 27);
            Pizza p29 = new Pizza("O Sole Mio", 65, "Cheese, Ham, Pinapple, Tofu", 28);
            Pizza p30 = new Pizza("Oriental", 45, "Tomato, Cheese, Bacone", 29);
            Pizza p31 = new Pizza("Oriental", 66, "Tomato, Cheese, Squash, Pinapple", 30);
            Pizza p32 = new Pizza("Sorento", 47, "Tomato, Cheese, Gorgonzola, Bacon", 31);
            Pizza p33 = new Pizza("UFO", 65, "Tomato, Cheese, Bacone, Mushroom", 32);

            ArrayList<Pizza> pizzasTemp = new ArrayList<Pizza>();
            pizzasTemp.add(p1);
            pizzasTemp.add(p2);
            pizzasTemp.add(p3);
            pizzasTemp.add(p4);
            pizzasTemp.add(p5);
            pizzasTemp.add(p6);
            pizzasTemp.add(p7);
            pizzasTemp.add(p8);
            pizzasTemp.add(p9);
            pizzasTemp.add(p10);
            pizzasTemp.add(p11);
            pizzasTemp.add(p12);
            pizzasTemp.add(p13);
            pizzasTemp.add(p14);
            pizzasTemp.add(p15);
            pizzasTemp.add(p16);
            pizzasTemp.add(p17);
            pizzasTemp.add(p18);
            pizzasTemp.add(p19);
            pizzasTemp.add(p20);
            pizzasTemp.add(p21);
            pizzasTemp.add(p22);
            pizzasTemp.add(p23);
            pizzasTemp.add(p24);
            pizzasTemp.add(p25);
            pizzasTemp.add(p26);
            pizzasTemp.add(p27);
            pizzasTemp.add(p28);
            pizzasTemp.add(p29);
            pizzasTemp.add(p30);
            pizzasTemp.add(p31);
            pizzasTemp.add(p32);
            pizzasTemp.add(p33);

// Collections.sort(pizzasTemp);
            c.setAttribute("pizzas", pizzasTemp);
            c.setAttribute("pizzaCount", pizzasTemp.size());
        }
        
        ArrayList<User> users = (ArrayList<User>) c.getAttribute("users");
        if (users == null) {

// creating content
            
            // USER
            User u1 = new User("Morteza", "moya@itu.dk", "abc123", "Rued Street 7", 2300, 24252627);
            u1.setValid(true);
           
            User u2 = new User("Amin", "amin@itu.dk", "abc123", "Rued Street 7", 2300, 24252627);
            u2.setValid(true);
            
            User u3 = new User("Radoslav", "rado@itu.dk", "abc123", "Rued Street 7", 2300, 24252627);
            u3.setValid(false);

            ArrayList<User> usersTemp = new ArrayList<User>();
            usersTemp.add(u1);
            usersTemp.add(u2);
            usersTemp.add(u3);

            // ADMIN user
            Admin a1 = new Admin("Admin1", "moya@itu.dk", "abc123", "Rued Street 7", 2300, 24252627);            
            a1.setValid(true);
            
            Admin a2 = new Admin("Admin2", "rado@itu.dk", "abc123", "Rued Street 7", 2300, 24252627);
            a2.setValid(true);

            usersTemp.add(a1);
            usersTemp.add(a2);

            c.setAttribute("users", usersTemp);
        }



// setting session variables
        HttpSession s = request.getSession();
        ArrayList<Pizza> sessionPizzas = (ArrayList<Pizza>) s.getAttribute("pizzas");
        if (sessionPizzas == null) {
            s.setAttribute("pizzas", c.getAttribute("pizzas")); //set session pizzas to context pizzas
        }

        Basket basket = new Basket();
//basket.addPizza(p1);
//basket.addPizza(p2);

        Basket sessionBasket = (Basket) s.getAttribute("basket");
        if (sessionBasket == null) {
            s.setAttribute("basket", basket);
        }

        /*
         User sessionUser = (User) s.getAttribute("user");
         if (sessionUser == null) {
         s.setAttribute("user", a2);
         }
         */


        /* printing out servlet context state
         response.setContentType("text/html");
         response.setDateHeader("Expires", 0);
         response.setHeader("Cache-Control",
         "no-store, no-cache, must-revalidate");
         response.setHeader("Pragma", "no-cache");
         PrintWriter out = response.getWriter();
         out.print("<html><head><title>Setup Status</title></head><body>"
         + "<h1>Servlet Context State</h1>");
         out.print("<form method=\"post\"><input type=\"button\" value=\"Menu\" OnClick=\"location.href='index.html'\">");

         ArrayList<Pizza> contextPizzas = (ArrayList<Pizza>) c.getAttribute("pizzas");
         out.print("<br><br>Pizzas:<br><table>");
         if (contextPizzas != null) {
         for (Pizza p : contextPizzas) {
         out.print("<tr><td>" + p.toString() + "</tr></td>");
         }
         out.print("</table>");
         }

         ArrayList<User> contextUsers = (ArrayList<User>) c.getAttribute("users");
         out.print("<br><br>Users:<br><table>");
         if (contextPizzas != null) {
         for (User u : contextUsers) {
         out.print("<tr><td>" + u.getName() + "</tr></td>");
         }
         out.print("</table>");
         }
         /*
         ArrayList<Admin> contextAdmins = (ArrayList<Admin>) c.getAttribute("admins");
         out.print("<br><br>Admins:<br><table>");
         if (contextAdmins != null) {
         for (Admin a : contextAdmins) {
         out.print("<tr><td>" + a.toString() + "</tr></td>");
         }
         out.print("</table>");
         }

         out.print("</body></html>");
         */
        response.setContentType("text/html");
        response.setDateHeader("Expires", 0);
        //need to set the appropriate HTTP header attributes to prevent the 
        //dynamic content output by the JSP page from being cached by the browser. 
        response.setHeader("Cache-Control",
                "no-store, no-cache, must-revalidate");  //HTTP 1.1
        response.setHeader("Pragma", "no-cache");        //HTTP 1.1
        PrintWriter out = response.getWriter();
        out.print("<html><head><title>Setup Status</title>");
        out.print("<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=home.jsp\"></head></html>");

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
    }
}
