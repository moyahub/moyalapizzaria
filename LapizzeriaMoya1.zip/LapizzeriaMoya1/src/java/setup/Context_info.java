package setup;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Admin;
import model.Pizza;
import model.User;

/**
 * Servlet implementation class Context_info
 */
public class Context_info extends HttpServlet {

    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Context_info() {
        super();
// TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
        ServletContext c = request.getServletContext();

        response.setContentType("text/html");
        response.setDateHeader("Expires", 0);
        response.setHeader("Cache-Control",
                "no-store, no-cache, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        PrintWriter out = response.getWriter();
        out.print("<html><head><title>Setup Status</title></head><body>"
                + "<h1>Context Info</h1>");

        ArrayList<Pizza> contextPizzas = (ArrayList<Pizza>) c.getAttribute("pizzas");
        out.print("<br><br>Pizzas:<br><table>");
        if (contextPizzas != null) {
            for (Pizza p : contextPizzas) {
                out.print("<tr><td>" + p.toString() + "</tr></td>");
            }
            out.print("</table>");
        }

        ArrayList<User> contextUsers = (ArrayList<User>) c.getAttribute("users");
        out.print("<br><br>Users:<br><table>");
        if (contextPizzas != null) {
            for (User u : contextUsers) {
                out.print("<tr><td>" + u.getName() + "</tr></td>");
            }
            out.print("</table>");
        }

        ArrayList<Admin> contextAdmins = (ArrayList<Admin>) c.getAttribute("admins");
        out.print("<br><br>Admins:<br><table>");
        if (contextAdmins != null) {
            for (Admin a : contextAdmins) {
                out.print("<tr><td>" + a.toString() + "</tr></td>");
            }
            out.print("</table>");
        }

        out.print("</body></html>");

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
    }
}
