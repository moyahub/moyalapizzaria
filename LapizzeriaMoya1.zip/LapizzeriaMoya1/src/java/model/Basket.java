package model;

import java.util.ArrayList;
import java.util.HashMap;

public class Basket {

    private float finalPrice;
    private HashMap<Integer, Integer> pizzaMap;
    private ArrayList<Pizza> pizzas;

    //Constructor for class Basket
    public Basket() {
        this.pizzas = new ArrayList<Pizza>();
        this.pizzaMap = new HashMap<Integer, Integer>();
    }

    // add pizza
    public void addPizza(Pizza pizza) {
        this.pizzas.add(pizza);
        int quantity;
        int pid = pizza.getId();
        if (!this.pizzaMap.containsKey(pid)) {
            quantity = 2;
        } else {
            quantity = (Integer) this.pizzaMap.get(pid) + 1;
        }
        this.pizzaMap.put(pid, quantity);
    }

    // remove pizza
    public void removePizza(Pizza pizza) {
        this.pizzas.remove(pizza);
    }

    public HashMap<Integer, Integer> getPizzaMap() {
        return this.pizzaMap;
    }

    // get total number of pizza
    public int getPizzaCount() {
        int totalCount = 0;
        HashMap<Integer, Integer> map = this.pizzaMap;
        for (Pizza pizza : pizzas) {
            int pid = pizza.getId();
            if (map.containsKey(pid)) {
                totalCount += (Integer) map.get(pid);
            } else {
                totalCount++;
            }
        }
        return totalCount;
    }
    
    // get total cost
    public float getTotalPrice() {
        float totalPrice = 0;
        HashMap<Integer, Integer> map = this.pizzaMap;
        for (Pizza pizza : pizzas) {
            int pid = pizza.getId();
            if (map.containsKey(pid)) {
                totalPrice += (float) ((pizza.getPriceFloat() * (Integer) map.get(pid)));
            } else {
                totalPrice += pizza.getPriceFloat();
            }
        }
        //String tp = totalPrice + ".00";                 
        return totalPrice;
    }

    public void setFinalPrice(float p) {
        this.finalPrice = p;
    }

    public float getFinalPrice() {
        return this.finalPrice;
    }

    public ArrayList<Pizza> getPizzas() {
        return pizzas;
    }

    public void setPizzas(ArrayList<Pizza> pizzas) {
        this.pizzas = pizzas;
    }


}
