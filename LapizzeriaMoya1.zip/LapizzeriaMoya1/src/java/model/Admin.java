package model;

public class Admin extends User {

    public Admin(String name, String email, String password, String address, int zipCode, int phoneNumber) {
        super(name, email, password, address, zipCode, phoneNumber);
    }

    public String toString() {
        return this.getName();
    }
}
