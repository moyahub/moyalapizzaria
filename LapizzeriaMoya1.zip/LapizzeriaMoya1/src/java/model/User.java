package model;

public class User {

    private String name;
    private String email; //userid, must be a valid email address         
    private String password; //Password must contain at least six characters, 
    //at least one digit, at least one letter character, and at least one 
    //spcial character like ] , $, etc. (anything other than punctation, 
    //separator or other), like Itu2$Guest
    private String address;
    private int zipCode; //must be 4 digits, 999 <danish zip code <10000 that is froom 999...9999        
    private int phoneNumber; //must be 8 digits         
    private boolean valid;

    public User(String name, String email, String password, String address, int zipCode, int phoneNumber) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.address = address;
        this.zipCode = zipCode;
        this.phoneNumber = phoneNumber;
        this.valid = false; //when a user is created it is per default not valid, 
        //as mail needs confirmation       
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public String toString() {
        return this.getName();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getZipCode() {
        return zipCode;
    }

    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
