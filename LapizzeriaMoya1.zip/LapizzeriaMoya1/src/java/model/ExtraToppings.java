package model;

public enum ExtraToppings {

    BACON, CHEESE, CHILI, ONION, HAM, PEPPERONI, BEEF, PINEAPPLE, TOMATOES, 
    PEPPER, GARLIC, MUSHROOM, TUNA, EGG
}
