package model;

import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Pizza implements Comparable {      
//public class Pizza {

    private int id;
    private String ingredients;
    private String name;
    private String price;
    private ArrayList<ExtraToppings> extraToppings;

    public Pizza() {
    }

    public Pizza(String name, String price, String ingredients, int id) {
        this.setName(name);
        this.setPrice(price);
        this.ingredients = ingredients;
        this.id = id;
        this.extraToppings = null;
    }

    public Pizza(String name, float price, String ingredients, int id) {
        this.setName(name);
        this.setPrice(price);
        this.ingredients = ingredients;
        this.id = id;
        this.extraToppings = null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPriceFloat() {
        Float f = new Float(price);
        return f;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(float price) {
        //DecimalFormat df = new DecimalFormat("#0.00");
        DecimalFormat df = new DecimalFormat("#.##");
        String str = df.format(price);
        this.price = str;
    }

    public void setPrice(String price) {
        //DecimalFormat df = new DecimalFormat("#0.00");
        DecimalFormat df = new DecimalFormat("#.##");
        
        Float f = new Float(price);
        String str = df.format(f);
        this.price = str;
    }

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public String toString() {
        return name + ". " + ingredients + ". price: " + price + "kr";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    //adding extra ingredient costs additional fee of 5kr
    public void addExtraTopping(ExtraToppings ingredient) {
        if (extraToppings == null) {
            extraToppings = new ArrayList<ExtraToppings>();
        }
        extraToppings.add(ingredient);
        price += 5;
    }

    public ArrayList<ExtraToppings> getExtraToppings() {
        return extraToppings;
    }

    public void setExtraToppings(ArrayList<ExtraToppings> extraToppings) {
        this.extraToppings = extraToppings;
    }

    @Override
    public int compareTo(Object p) {
        return (int) (this.getPriceFloat() - ((Pizza) p).getPriceFloat());
    }

    @Override
    public Pizza clone() {
        Pizza clone = new Pizza(this.name, this.price, this.ingredients, this.id);
        return clone;
    }
}
