package util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
//at least one digit - at least one letter character (upper or lower case) 
//- at least one non-word character - at least six characters 
// Password Regular Expression Pattern: ((?=.*\\d)(?=.*[a-zA-Z])(?=.*\\W).{6,})
// descirption:   
// (              # start of group
// (?=.*\\d)      # at least must contain one digit/numeric 
// (?=.*[a-zA-Z]) # at least one letter character (upper or lower case)
// (?=.*\\W)      #  at least one special characterlike  ] , $, etc. (anything other than punctation, separator or other), like Itu2$Guest
// {6,}           # at least 6 characters length, there is no max length   
// )              # end of group

    private static final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-zA-Z])(?=.*\\W).{6,})";

    public static boolean isPassword(String password) {
        boolean isValid = false;
        Pattern pattern = Pattern.compile(PASSWORD_PATTERN);
        Matcher matcher = pattern.matcher(password);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isPhoneNumber(String phoneNumber) {
        boolean isValid = false;
        Pattern pattern = Pattern.compile("\\d{8}");
        Matcher matcher = pattern.matcher(phoneNumber);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isZipCode(String zipCode) {
        boolean isValid = false;
        try {
            int zip = Integer.parseInt(zipCode);
            if (zip > 999 && zip < 10000) {
                isValid = true;
            }
        } catch (Exception e) {
        }
        return isValid;
    }
}
