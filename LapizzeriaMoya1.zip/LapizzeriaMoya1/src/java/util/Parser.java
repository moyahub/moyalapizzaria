package util;

import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


import model.Pizza;

public class Parser {

    private Document dom;

    public static void main(String[] args) {

        ArrayList<Pizza> pa = getRemotePizzas("40.00", "60.00");

//Tester function
        System.out.println("No of Pizzas '" + pa.size() + "'.");

        Iterator<Pizza> it = pa.iterator();
        while (it.hasNext()) {
            System.out.println(it.next().toString());
        }
    }

    public static ArrayList<Pizza> getRemotePizzas(String paraMin, String paraMax) {

        Parser ps = new Parser();
        String uri = getUri(paraMin, paraMax);
        ps.parseXmlFile(uri);
        return ps.parseDocument();

    }

    private void parseXmlFile(String para) {

        try {
//Create instance of DocumentBuilderFactory
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
//Get the DocumentBuilder
            DocumentBuilder parser = factory.newDocumentBuilder();
//Create blank DOM Document
            this.dom = parser.parse(para);
            System.out.println("Root element of the doc is "
                    + this.dom.getDocumentElement().getNodeName());
//Element docEle = dom.getDocumentElement();
//System.out.println("docEle: " + docEle.toString());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private ArrayList<Pizza> parseDocument() {
        ArrayList<Pizza> pa = new ArrayList<Pizza>();
//get the root element
        Element docEle = this.dom.getDocumentElement();

//get a nodelist of elements
        NodeList nl = docEle.getElementsByTagName("pizza");
        if (nl != null && nl.getLength() > 0) {
            for (int i = 0; i < nl.getLength(); i++) {

//get the pizza element
                Element pe = (Element) nl.item(i);

//get the data for the pizza
                int id = (Integer.parseInt(getTextValue(pe, "id")) + 10000);
                String name = getTextValue(pe, "name");
                float price = Float.parseFloat(getTextValue(pe, "price"));
                String ingredients = getTextValue(pe, "ingredients");

//creates the pizza object
                Pizza p = new Pizza(name, price, ingredients, id);

//add the pizza to list
                pa.add(p);
            }
        }
        return pa;
    }

    private static String getUri(String paraMin, String paraMax) {

        String uri = "http://108.166.80.162:8080/LaPizzaria/rest/pizza";
        if (paraMin.isEmpty() && paraMax.length() > 0) {
            uri = uri + "?maxprice=" + paraMax;
        } else if (paraMin.length() > 0 && paraMax.isEmpty()) {
            uri = uri + "?minprice=" + paraMin;
        } else if (paraMin.length() > 0 && paraMax.length() > 0) {
            uri = uri + "?minprice=" + paraMin + "&maxprice=" + paraMax;
        }
        return uri;
    }

    /**
     * I take a xml element and the tag name, look for the tag and get the text
     * content i.e for <employee><name>John</name></employee> xml snippet if the
     * Element points to employee node and tagName is 'name' I will return John
     */
    private String getTextValue(Element ele, String tagName) {
        String textVal = null;
        NodeList nl = ele.getElementsByTagName(tagName);
        if (nl != null && nl.getLength() > 0) {
            Element el = (Element) nl.item(0);
            textVal = el.getFirstChild().getNodeValue();
        }

        return textVal;
    }
}
