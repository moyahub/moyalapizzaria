package util;  
import java.io.IOException; 
import java.util.ArrayList; 
import javax.xml.parsers.*; 
import org.xml.sax.SAXException; 
import org.w3c.dom.*;  

import model.Pizza;  
public class PizzaMethods {

    Document dom;

    public static int getPizzaArrayIndex(ArrayList<Pizza> pizzas, int p_id) {
        int index = -1;
        for (int i = 0; i < pizzas.size(); i++) {
            Pizza p = pizzas.get(i);
            if (p.getId() == p_id) {
                index = i;
            }
        }
        return index;
    }
}
